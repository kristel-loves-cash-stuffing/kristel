
(function(){
  var modal = document.getElementById('photoModal');
  var modalImage = document.getElementById('modalImage');
  var modalCaption = document.getElementById('modalCaption');
  var close = modal ? modal.querySelector('.modal-close') : null;

  document.querySelectorAll('.photo-button').forEach(function(btn){
    btn.addEventListener('click', function(){
      modalImage.src = btn.dataset.full;
      modalImage.alt = btn.dataset.title || '';
      modalCaption.textContent = btn.dataset.title || '';
      modal.classList.add('open');
      modal.setAttribute('aria-hidden','false');
      document.body.style.overflow='hidden';
    });
  });

  function closeModal(){
    if(!modal) return;
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden','true');
    document.body.style.overflow='';
    modalImage.src='';
  }

  if(close) close.addEventListener('click', closeModal);
  if(modal) modal.addEventListener('click', function(e){
    if(e.target === modal) closeModal();
  });
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape') closeModal();
  });
})();
