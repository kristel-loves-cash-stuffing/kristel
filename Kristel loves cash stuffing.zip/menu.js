
(function(){
  var btn = document.getElementById('menuBtn');
  var panel = document.getElementById('menuPanel');
  if (!btn || !panel) return;
  function closeMenuInstant(){
    panel.style.transition = 'none';
    btn.setAttribute('aria-expanded','false');
    panel.classList.remove('is-open');
    void panel.offsetHeight;
    panel.style.transition = '';
  }
  btn.addEventListener('click', function(){
    var open = btn.getAttribute('aria-expanded') === 'true';
    btn.setAttribute('aria-expanded', String(!open));
    panel.classList.toggle('is-open', !open);
  });
  panel.querySelectorAll('a').forEach(function(a){
    a.addEventListener('click', closeMenuInstant);
  });
})();
